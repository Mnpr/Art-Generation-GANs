# Exploration of Art Generation using Deep Generative models.

---

**>>> Biweekly Report 2.** ( $9^{th} Dec - 23^{th} Dec : 2020 $)

---

**Contents**

1. Implementation Status/ Progress
2. Convolution
3. Convolutional Neural Network Concepts
4. Deep Convolutional GAN using PyTorch ( Implementation )
5. Observations
   - MNIST Dataset
   - CelebA Dataset
   - Art Dataset
6. Conclusion
   - Criterias, Drawbacks, and Possible Solutions ( Insight next iteration )
7. Reference/ Candidate Papers

---

**>>> Submitted by :** Sudesh Acharya (932253) @FH-Kiel

---

## 1. Implementation Status/ Progress

### Current Iteration

**[ :white_check_mark: Completed ] [ :stopwatch: Time Approx(Hours) ] [ :computer: Implementaiton | :spiral_notepad: Documentation ]**

- [x] [ 3 ] Convolution Operation & CNN Concepts

- [x] [ 9  ] Deep Convolution Gan Paper ( Implementation )

- [x] [ 5 ] Development and Debugging

- [x] [ 11 ] Observation on Different Datasets
  
  - [x] [ 2 ] MNIST
  
  - [x] [ 3 ] CelebA
  
  - [x] [ 5 ] Art Datasets
  
  - [ ] [ 1] LSUN Church Dataset ( Incomplete )

- [x] [ 7 ] Observations: Different Hyperparameter settings.

- [x] [ 2 ] Optimization Techniques

- [x] [ 1.5 ] Conclusion

- [x] [ 3.5 ] Report Documentation.



**Total Time (Hours)** $\approx$ 42 hours

****

## 2. Convolution

Convolution operation combines two functions  ( like sum or multiplication operation ) and outputs third function :

- **Continuous** Input $x$ and Kernel $w$ 

$$
\boxed{ s(t) = (x \circledast w)(t) = \int x(a)w(t-a)da}
$$

- **Discrete t :**

$$
\boxed{ s(t) = (x \circledast w)(t) = \displaystyle\sum_{a} x(a)w(t-a) }
$$

#### Properties:

- Commutative : $f(x) \circledast g(x) = g(x) \circledast f(x)$

- Associative : $(f(x) \circledast g(x) \circledast h(x)) = f(x) \circledast (g(x) \circledast h(x))$

- Distributive : $f(x) \circledast (g(x) + h(x)) = f(x) \circledast g(x) + f(x) \circledast h(x)$

- Circularity, Identity etc.

## 3. Convolutional Neural Networks

- In CNN terms $S$  is : `Feature Map`

- Cross-correlation is same as convolution with flipped kernel( if kernel = symmetric )

- Most practical application of CNN use Cross-correlation instead of Convolutions due to it's simplicity

- Different Kernels can be used to highlights different features from images.

- Convolution layers provide Local Connectivity  and Spatial kernel parameter sharing on top of Multilayer Perceptron( Fully Connected Networks )

#### Terminologies ( CNN )

**Stride :** Applying the filter with different step size on Image patches (e.g. Stride =2 with shift the filter 2 steps forward )

**Padding :** Extending image borders ( Mostly with value '0')

**Pooling/ Subsampling** : Reducing parameters/ make representations smaller ( Max | Average Pooling)

**Transpose Convolution** : Devonvolution or Reverse Convolution 

## 4. Deep Convolutional GAN Implementation (PyTorch)

DC-GAN specially focuses on using the Deep Convolutional network in place of Fully-connected networks. Convolutional network in general find areas of correlation( Spatial Correlation ) within images and hence are better suited for Images/Videos.

- Ref: train.py ( Main script to run for Training and Tuning the network )

- Ref: model.py ( Contains Generator and Discriminator Classes )



**Network Configuration**

The idea/guidelines proposed in the DC-GAN paper [[Ref 1.]](https://arxiv.org/pdf/1511.06434.pdf)  :

- Use of Convolutional layers instead of fully connected hidden layers for deep architectures

- Replacing any pooling layers with strided convolutions (discriminator) and fractional-strided convolutions (generator).

- Using batchnorm in both the generator and the discriminator.

- Using ReLU activation in generator for all layers except for the output, which uses tanh.

- Using LeakyReLU activation in the discriminator for all layer.

## Discriminator ( ART Critic )

As previously seen in Fully Connected GANs, Discriminator is also a binary classifier in this case distinguishing betweek real(0) and fake(1) art. The Discriminator is composed of :

![](./D.png) 

**Sequential Blocks :**

- Input layer: Image of size ( 64 x 64  ) RGB image

- 2D convolution ( Stride : 2, Kernel size: 4, Padding: 1) [ 64 x 64 ]

- Leaky Relu( negative slope : 0.2 )

- 2D convolution ( Stride : 2, Kernel size: 4, Padding: 1) [ 32 x 32 ]

- Batch Normalization()

- Leaky Relu( negative slope : 0.2 )

- 2D convolution ( Stride : 2, Kernel size: 4, Padding: 1) [ 16 x 16 ]

- Batch Normalization()

- Leaky Relu( negative slope : 0.2 )

- 2D convolution ( Stride : 2, Kernel size: 4, Padding: 1) [ 8 x 8 ]

- Batch Normalization

- Leaky Relu( negative slope : 0.2 )

- 2D convolution ( Stride : 2, Kernel size: 4, Padding: 0) [ 4 x 4 ]

- Sigmoid( Probability of being fake or real ) [1 x 1]

The Discriminator learns to classify between real and fake images by taking real images from training samples and fake noise from the generator. It can be separated from generator after the completion of training and used as classifier, since it doesnot have any role while sampling realistic fake images from generator.

## Generator ( Art Generator )

Generator is more complex network than discriminator. It starts with a noise generated from latent space ( assumption of space where the feature explaining the distribution of input images lies ). A 100 dimensional( in this case ) uniform distrinbution is then projected to a small spatial [ here 4x4]  convolutional representation with many feature maps [ in figure : 1024 ]. The Generator  is composed of :

![](./G.png)

[@ImgSource D, G](https://www.oreilly.com/content/deep-convolutional-generative-adversarial-networks-with-tensorflow/)

**Sequential Layers :**

- 2DTransposeConv. ( Stride: 1, Kernel size: 4, padding: 0) 

- Batch Normalization()

- ReLU()

- 2DTransposeConv. ( Stride: 2, Kernel size: 4, padding: 1) [4 x 4]

- Batch Normalization()

- ReLU()

- 2DTransposeConv. ( Stride: 2, Kernel size: 4, padding: 1) [8 x 8]

- Batch Normalization()

- ReLU()

- 2DTransposeConv. ( Stride: 2, Kernel size: 4, padding: 1) [16 x 16]

- Batch Normalization()

- ReLU()

- 2DTransposeConv. ( Stride: 2, Kernel size: 4, padding: 1) [32 x 32]

- Tanh() [ 64 x 64 ]

The generator tries to learn the distribution which explains the training datasets. Generator is not directly exposed to training examples instead based on generation of noise being realistic it gets feedback from discriminator, improving with each iteration .

## 5. Observation

### i. MNIST Datasets

The MNIST datasets with different hyperparameter was experimented

**Hyperparameters**

```python
LEARNING_RATE = 2e-4 
BATCH_SIZE = 32 # Sampling
IMAGE_SIZE = 64
CHANNELS_IMG = 1
Z_DIM = 100
NUM_EPOCHS = 10
FEATURES_DISC = 64
FEATURES_GEN = 64

# 1 Epoch = 18 steps( 100 in each mini-batch)
```

**Epoch0( = 18 step of Gradient Descent )**

![](./samples/SampleEpoch0_mnist.png)

**Epoch1**

![](./samples/SampleEpoch1_mnist.png)

**Epoch10**

![](./samples/SampleEpoch10_mnist.png)

WIth the higher number of epochs the generator will only produce realistic images untill the training is saturated. 

### ii.  CelebA Datasets

With the inclusion of Batch normalization and Convolutional Neural Networks it performs better that the Vanilla Fully Connected-GAN.

**Hyperparameters**

```python
LEARNING_RATE = 2e-4 
BATCH_SIZE = 32 
IMAGE_SIZE = 64
CHANNELS_IMG = 3
Z_DIM = 100
NUM_EPOCHS = 50
FEATURES_DISC = 64
FEATURES_GEN = 64
```

**Epoch 3**

![](./samples/SampleEpoch3_celeb.png)

**Epoch 10**

![](./samples/SampleEpoch10_celeb.png)

**Epoch25**

![](./samples/SampleEpoch25_celeb.png)

**Epoch50**

![](./samples/SampleEpoch50_celeb.png)

As it can be seen from the observation for 50 Epochs the model performs quite well since the image has to only learn the representation of faces( Diverse faces but not diverse datasets ) .

### iii. Art Datasets

**Hyperparameters**

```python
LEARNING_RATE = 2e-4 
BACH_SIZE = 32 
IMAGE_SIZE = 64
CHANNELS_IMG = 3
Z_DIM = 100
NUM_EPOCHS = 300
FEATURES_DISC = 64
FEATURES_GEN = 64
# Mini-batch size for Gradient Descent = 100
```

**Epoch1**

![](./samples/sampleEpoch1.png)

**Epoch 5**

![](./samples/sampleEpoch5.png)

**Epoch 50**

![](./samples/sampleEpoch50.png)

**Epoch 70**

![](./samples/sampleEpoch70.png)

**Epoch 100**

![](./samples/sampleEpoch100.png)

**Epoch 200**

![](./samples/sampleEpoch200.png)

**Epoch 300**

![](./samples/sampleEpoch300.png)

The given samples are 64 x 64 and as we can see after passing the datasets 300 times through the network it generates samples that are similar to each other ( as in samples from 300 Epochs ) . The challenging part to generate samples from this network is that the dataset contains huge amount of diverse and noisy images (e.g. one of the training sample ). 

![](./samples/train_sample.png)

Personally i think 'Art( abstract ) is Finding Pattern in Randomness and most of the artwork are not realistic in themselves since some information is left out compared to real world examples (eg. photographs )  for the interpreter to fill in with their own' atleast for humans but GANs have very hard time extracting similar patterns (of diverse patterns ) and map them to latent space. 



One another issue is the resolution of the output images. Several attempts were made with different network settingsin order to produce 128 x 128 images and some of the samples are : 

**Epoch 5**

![](samples/sampleEpoch5_128.png)

**Epoch 20**

![](samples/sampleEpoch20_128.png)

**Epoch 40**

![](samples/sampleEpoch40_128.png)

**Epoch 50**

![](samples/sampleEpoch50_128.png)

## 6. Conclusion

Since GANs consists of two different networking working as adversaries to each other, there are several challenging factors contributing to stable and optimal training. some of the challenges include:

- Requirement of Nash equillibrium ( Saturated training ) without the availability of explicit optimization of loss function.

- Either of the adversaries cannot be superior to other i.e. superior Discriminator may reject all the generated image as fake with high confidence and superior Generator may generate image which is distinguished as real by discriminatior. Both cases may lead to instability and no-learning in the network

- The Art Dataset itself is so diverse and the pixels are noisy( more randomness ) than other dataset( e.g. faces, dogs, ...) which were observed during training networks with same setting on art and CelebA face datasets.[ Ref: Observation :arrow_up: ] 

Some of the tricks to mitigate given challenges were to decrease the initial confidence of discriminator by 10%. Although the loss function doesnot tell much but we can  track them to see if both adversaries are learning in the same level.

Ideas for the future iteration  is to try Data Augmentation or Truncated sampling( Tradeoff : Quality :arrows_counterclockwise: Diversity) from the generator etc. GANs do not calculate the density function explicitly and uses something close to *Jensen-Shannon(JS) Divergence* in contrast to their rival AutoEncoders. which uses KL-Divergence to measure the efforts needed to move latent disrtibution closer to the real one . In the next iteration, the plan is to implement wasserstein distance instead which is observed to be more stable than the JS divergence.

## 7. References :

- [1. ] [Unsupervised Representation Learning with Deep Convolutional Generative Adversarial Networks](https://arxiv.org/pdf/1511.06434.pdf)
- [2. ] [Conv Nets: A Modular Perspective](https://colah.github.io/posts/2014-07-Conv-Nets-Modular/)
